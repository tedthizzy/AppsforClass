//
//  CollectionSupplementaryView.swift
//  pictureCollection
//
//  Created by Frederick Thayer on 2/21/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class CollectionSupplementaryView: UICollectionReusableView {
    
    @IBOutlet weak var headerLabel: UILabel!
    
        
}
