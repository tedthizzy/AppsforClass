//
//  CollectionViewCell.swift
//  pictureCollection
//
//  Created by Frederick Thayer on 2/21/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
    
}
