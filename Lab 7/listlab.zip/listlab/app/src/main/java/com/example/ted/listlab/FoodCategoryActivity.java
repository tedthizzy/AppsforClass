package com.example.ted.listlab;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by ted on 4/18/17.
 */

public class FoodCategoryActivity extends ListActivity {

    private String foodtype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        foodtype = i.getStringExtra("foodtype");

        ListView listBulbs = getListView();

        ArrayAdapter<Food> listAdapter;

        switch (foodtype){
            case "Breakfast":
                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.breakfast);
                break;
            case "Lunch":
                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.lunch);
                break;
            case "Dinner":
                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.dinner);
                break;
            default: listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.breakfast);
        }

        listBulbs.setAdapter(listAdapter);

    }

    @Override
    public void onListItemClick(ListView listView, View view, int position, long id) {
        Intent intent = new Intent(FoodCategoryActivity.this, FoodActivity.class);
        intent.putExtra("foodid",(int) id);
        intent.putExtra("foodtype",foodtype);
        startActivity(intent);
    }

}
