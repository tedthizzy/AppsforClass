package com.example.ted.listlab;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class FoodActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        int foodnum = (Integer) getIntent().getExtras().get("foodid");
        String type = (String) getIntent().getExtras().get("foodtype");

        Food food;
/*
        switch (foodnum) {
            case 0:
                Food food = Food.breakfast[foodnum];
                break;
            case 1:
                Food food = Food.lunch[foodnum];
                break;

            case 2:
                Food food = Food.dinner[foodnum];
                break;
            default:
                Food food = Food.breakfast[foodnum];
                break;

        }
*/

        if (type.equals("Breakfast")) {
            food = Food.breakfast[foodnum];
        } else {

            if (type.equals("Lunch")) {
                food = Food.lunch[foodnum];
            } else {

                if (type.equals("Dinner")) {
                    food = Food.dinner[foodnum];
                } else {
                    food = Food.breakfast[foodnum];
                }
            }
        }


                ImageView foodImage = (ImageView) findViewById(R.id.foodImageView);
                foodImage.setImageResource(food.getImageResourceID());
                TextView foodName = (TextView) findViewById(R.id.food_name);
                foodName.setText(food.getName());

            }
        }
