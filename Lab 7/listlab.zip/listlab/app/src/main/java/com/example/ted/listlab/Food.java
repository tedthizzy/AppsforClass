package com.example.ted.listlab;

/**
 * Created by ted on 4/18/17.
 */

public class Food {

    private String name;
    private int imageResourceID;

    private Food(String newname, int newID){
        this.name = newname;
        this.imageResourceID = newID;
    }

    public static final Food[] breakfast = {
            new Food("Water", R.drawable.water),
            new Food("Cereal", R.drawable.cereal),
            new Food("Pancakes", R.drawable.pancakes),
    };

    public static final Food[] lunch = {
            new Food("Pb&j", R.drawable.pbj),
            new Food("Soylent", R.drawable.soylent),
    };

    public static final Food[] dinner = {
            new Food("Pasta", R.drawable.pasta),
            new Food("Chicken", R.drawable.chicken),
    };

    public String getName(){
        return name;
    }

    public int getImageResourceID(){
        return imageResourceID;
    }

    public String toString(){
        return this.name;
    }
}
