//
//  RunsTableViewController.swift
//  Midterm
//
//  Created by Frederick Thayer on 3/16/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class RunsTableViewController: UITableViewController {
    
    var runs = [String]()
    var selectedResort = 0
    var resortListDetail = Resorts()
    
    var searchController: UISearchController!
/*
    func getDataFile() -> String? {
        guard let pathString = Bundle.main.path(forResource: "resorts",ofType:"plist") else {
            return nil
        }
        return pathString
    }
*/
    override func viewWillAppear(_ animated: Bool) {
        resortListDetail.resorts = Array(resortListDetail.resortData.keys)
        let chosenResort = resortListDetail.resorts[selectedResort]
        runs = resortListDetail.resortData[chosenResort]! as [String]
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
/*
        guard let path = getDataFile() else{
            print("Error loading file")
            return
        }
 */
        
        resortListDetail.resorts = Array(resortListDetail.resortData.keys)
        let chosenResort = resortListDetail.resorts[selectedResort]
        runs = resortListDetail.resortData[chosenResort]! as [String]
        print(runs)
        
       // runs = NSArray(contentsOfFile:path) as! Array
        
        self.tableView.contentInset = UIEdgeInsetsMake(20,0,0,0)
        
        let resultsController = SearchResultsController()
        resultsController.allwords = runs
        searchController = UISearchController(searchResultsController: resultsController)
        searchController.searchBar.placeholder = "Enter a search term"
        searchController.searchBar.sizeToFit()
        tableView.tableHeaderView=searchController.searchBar
        searchController.searchResultsUpdater = resultsController

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        print("view will disappear")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return runs.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellIdentifier", for: indexPath)
        cell.textLabel?.text = runs[indexPath.row]
        return cell
        
        // Configure the cell...
        
        
    }
    
    
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            runs.remove(at: indexPath.row)
            let chosenResort = resortListDetail.resorts[selectedResort]
            resortListDetail.resortData[chosenResort]?.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    
    
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
        
        let fromRow = fromIndexPath.row
        let toRow = to.row
        let moveRun = runs[fromRow]
        runs.remove(at: fromRow)
        runs.insert(moveRun, at: toRow)
        let chosenResort = resortListDetail.resorts[selectedResort]
     //   resortListDetail.resortData[selectedResort]?.remove(at: fromRow)
    //    resortListDetail.resortData[selectedResort]?.insert(moveRun, at: toRow)
        
    }
    
    
    
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    
    @IBAction func unwindSegue(_ segue:UIStoryboardSegue){
        if segue.identifier == "doneSegue"{
            let source = segue.source as! AddRunsViewController
            if ((source.addedRun.isEmpty)==false){
                runs.append(source.addedRun)
                tableView.reloadData()
                let chosenResort = resortListDetail.resorts[selectedResort]
                resortListDetail.resortData[chosenResort]?.append(source.addedRun)}
        }}
}


