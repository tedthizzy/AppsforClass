//
//  AddRunsViewController.swift
//  Midterm
//
//  Created by Frederick Thayer on 3/16/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class AddRunsViewController: UIViewController {
    
    @IBOutlet weak var runTextfield: UITextField!
    
    var addedRun = String()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneSegue"{
            if ((runTextfield.text?.isEmpty) == false){ // check if nothing is entered
                addedRun = runTextfield.text!
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
