//
//  Resorts.swift
//  Midterm
//
//  Created by Frederick Thayer on 3/16/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import Foundation


class Resorts {
    var resortData = [String : [String]]()
    var resorts = [String]()
}
