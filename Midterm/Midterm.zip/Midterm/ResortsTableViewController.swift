//
//  ResortsTableViewController.swift
//  Midterm
//
//  Created by Frederick Thayer on 3/16/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class ResortsTableViewController: UITableViewController {
    
    var resortList = Resorts()
    let kfilename = "data.plist"
    
    func getDataFile() -> String? {
        guard let pathString = Bundle.main.path(forResource: "resorts",ofType:"plist") else {
            return nil
        }
        return pathString
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let path:String?
        let filePath = docFilePath(kfilename)
        
        if FileManager.default.fileExists(atPath: filePath!){
            path = filePath
        }
        else {
            path = getDataFile()
        }
        /*
         guard let path = getDataFile() else{
         print("Error loading file")
         return
         }
         // Do any additional setup after loading the view, typically from a nib.
         */
        resortList.resortData = NSDictionary(contentsOfFile: path!) as! [String : [String]]
        resortList.resorts = Array(resortList.resortData.keys)
        
        let app = UIApplication.shared
        NotificationCenter.default.addObserver(self, selector: #selector(UIApplicationDelegate.applicationWillResignActive(_:)), name: NSNotification.Name(rawValue: "UIApplicationWillResignActiveNotification"), object: app)
        
    }
    
    override func viewWillAppear(_ animated: Bool){
        print("view will appear")
    }
    
    /*
     
     override func preparetounwind(_ segue: UIStoryboardSegue){
     print("unwinding")
     }
     
     */
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resortList.resortData.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellIdentifier", for: indexPath)
        cell.textLabel?.text = resortList.resorts[indexPath.row]
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "runsegue" {
            let detailVC = segue.destination as! RunsTableViewController
            let indexPath = tableView.indexPath(for: sender as! UITableViewCell)!
            detailVC.title = resortList.resorts[indexPath.row]
            detailVC.resortListDetail = resortList
            detailVC.selectedResort = indexPath.row
        } /*else if segue.identifier == "continentsegue"{
            let infoVC = segue.destination as! ContinentInfoTableTableViewController
            let editingCell = sender as! UITableViewCell
            let indexPath = tableView.indexPath(for: editingCell)
            infoVC.name = continentList.continents[indexPath!.row]
            let countries = continentList.continentData[infoVC.name]! as [String]
            infoVC.number = String(countries.count)
        } */
    }
    
    func docFilePath(_ filename: String) -> String?{
        // locate documents directory
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.allDomainsMask, true)
        let dir = path[0] as NSString // document directory
        return dir.appendingPathComponent(filename)
    }
    
    func applicationWillResignActive(_ notification: Notification){
        let filePath = docFilePath(kfilename)
        let data = NSMutableDictionary()
        data.addEntries(from: resortList.resortData)
        data.write(toFile: filePath!, atomically: true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
