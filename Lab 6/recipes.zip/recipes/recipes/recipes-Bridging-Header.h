//
//  recipes-Bridging-Header.h
//  recipes
//
//  Created by Frederick Thayer on 3/23/17.
//  Copyright © 2017 FMT. All rights reserved.
//

#ifndef recipes_Bridging_Header_h
#define recipes_Bridging_Header_h

#import <GoogleSignIn/GoogleSignIn.h>


#endif /* recipes_Bridging_Header_h */
