//
//  MealsTableViewController.swift
//  groceries
//
//  Created by Frederick Thayer on 2/22/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class MealsTableViewController: UITableViewController {
    
    var mealsList = Meals()
    let kfilename = "data.plist"
    func getDataFile() -> String? {
        guard let pathString = Bundle.main.path(forResource: "meals",ofType:"plist") else {
            return nil
        }
        return pathString
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let path:String?
        let filePath = docFilePath(kfilename)
        
        if FileManager.default.fileExists(atPath: filePath!){
            path = filePath
        }
        else {
            path = getDataFile()
        }
        
        /*
         guard let path = getDataFile() else{
         print("Error loading file")
         return
         }
         // Do any additional setup after loading the view, typically from a nib.
         */
        
        mealsList.mealsData = NSDictionary(contentsOfFile: path!) as! [String : [String]]
        mealsList.meals = Array(mealsList.mealsData.keys)
        
        
        let app = UIApplication.shared
        NotificationCenter.default.addObserver(self, selector: #selector(UIApplicationDelegate.applicationWillResignActive(_:)), name: NSNotification.Name(rawValue: "UIApplicationWillResignActiveNotification"), object: app)
        
        
        
        
    }
    
    override func viewWillAppear(_ animated: Bool){
        print("view will appear")
 
        
    }
    
    /*
     
     override func preparetounwind(_ segue: UIStoryboardSegue){
     print("unwinding")
     }
     
     */
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mealsList.mealsData.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellIdentifier", for: indexPath)
        cell.textLabel?.text = mealsList.meals[indexPath.row]
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ingredientsegue" {
            let detailVC = segue.destination as! IngredientsTableViewController
            let indexPath = tableView.indexPath(for: sender as! UITableViewCell)!
            detailVC.title = mealsList.meals[indexPath.row]
            detailVC.mealsListDetail=mealsList
            detailVC.selectedMeal = indexPath.row
        } else if segue.identifier == "mealsegue"{
            let infoVC = segue.destination as! OverviewTableViewController
            let editingCell = sender as! UITableViewCell
            let indexPath = tableView.indexPath(for: editingCell)
            infoVC.name = mealsList.meals[indexPath!.row]
            let countries = mealsList.mealsData[infoVC.name]! as [String]
            infoVC.number = String(countries.count)
        }
    }
    
    func docFilePath(_ filename: String) -> String?{
        // locate documents directory
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.allDomainsMask, true)
        let dir = path[0] as NSString // document directory
        return dir.appendingPathComponent(filename)
    }
    
    func applicationWillResignActive(_ notification: Notification){
        let filePath = docFilePath(kfilename)
        let data = NSMutableDictionary()
        data.addEntries(from: mealsList.mealsData)
        data.write(toFile: filePath!, atomically: true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
