//
//  OverviewTableViewController.swift
//  groceries
//
//  Created by Frederick Thayer on 2/22/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class OverviewTableViewController: UITableViewController {
    
    @IBOutlet weak var mealName: UILabel!
    @IBOutlet weak var ingredientNumber: UILabel!
    
    var name = String()
    var number = String()
    
    override func viewWillAppear(_ animated: Bool) {
        mealName.text = name
        ingredientNumber.text = number
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    

}
