//
//  AddFoodViewController.swift
//  groceries
//
//  Created by Frederick Thayer on 2/22/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class AddFoodViewController: UIViewController {
    
    
    @IBOutlet weak var ingredientTextField: UITextField!
    
    var addedIngredient = String()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneSegue"{
            if ((ingredientTextField.text?.isEmpty) == false){
                
                addedIngredient = ingredientTextField.text!
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
