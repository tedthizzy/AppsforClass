//
//  MyraViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 2/25/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class MyraViewController: UIViewController {

    
    @IBOutlet weak var myraPic: UIImageView!
    
    var myDat = myraData()

//    var myraInfo:String!
//    var mathInfo:Int!
//    var myraTempTag: String! = ""
////    let myraTempTag = myraInfo//= "h1b1l1"
//    var head_num: Int! //= 1
//    var body_num: Int! //= 1
//    var legs_num: Int! //= 1
    
    

    
    
    @IBAction func head_next(_ sender: UIButton) {
        
        if myDat.head_num == 0 {
            myDat.head_num = 2
            myDat.body_num = 2
            myDat.legs_num = 2
        }
        
        if myDat.head_num == 3 {
            myDat.head_num = 1
        } else {
            myDat.head_num = myDat.head_num+1
        }
        
        myDat.myraInfo = "h"+String(myDat.head_num)+"b"+String(myDat.body_num)+"l"+String(myDat.legs_num)+".png"
        myraPic.image=UIImage(named:myDat.myraInfo)
        
        print(myDat.myraInfo)
        
    }
    
    @IBAction func body_next(_ sender: UIButton) {
        
        if myDat.head_num == 0 {
            myDat.head_num = 2
            myDat.body_num = 2
            myDat.legs_num = 2
        }
        
        if myDat.body_num == 3 {
            myDat.body_num = 1
        } else {
            myDat.body_num = myDat.body_num+1
        }
        
        myDat.myraInfo = "h"+String(myDat.head_num)+"b"+String(myDat.body_num)+"l"+String(myDat.legs_num)+".png"
        myraPic.image=UIImage(named:myDat.myraInfo)
        
    }
    
    @IBAction func legs_next(_ sender: UIButton) {
        
        if myDat.head_num == 0 {
            myDat.head_num = 2
            myDat.body_num = 2
            myDat.legs_num = 2
        }
        
        if myDat.legs_num == 3 {
            myDat.legs_num = 1
        } else {
            myDat.legs_num = myDat.legs_num+1
        }
        
        myDat.myraInfo = "h"+String(myDat.head_num)+"b"+String(myDat.body_num)+"l"+String(myDat.legs_num)+".png"
        myraPic.image=UIImage(named:myDat.myraInfo)
        
    }
    
    @IBAction func head_back(_ sender: UIButton) {
        
        print(myDat.head_num)
        print(myDat.body_num)
        print(myDat.legs_num)
        
        if myDat.head_num == 0 {
            myDat.head_num = 2
            myDat.body_num = 2
            myDat.legs_num = 2
        }
        
        if myDat.head_num == 1 {
            myDat.head_num = 3
        } else {
            myDat.head_num = myDat.head_num-1
        }
        
        myDat.myraInfo = "h"+String(myDat.head_num)+"b"+String(myDat.body_num)+"l"+String(myDat.legs_num)+".png"
        myraPic.image=UIImage(named:myDat.myraInfo)
        
        print(myDat.myraInfo)
        print(myDat.head_num)
        
    }
    
    @IBAction func body_back(_ sender: UIButton) {
        
        if myDat.head_num == 0 {
            myDat.head_num = 2
            myDat.body_num = 2
            myDat.legs_num = 2
        }
        
        if myDat.body_num == 1 {
            myDat.body_num = 3
        } else {
            myDat.body_num = myDat.body_num-1
        }
        
        myDat.myraInfo = "h"+String(myDat.head_num)+"b"+String(myDat.body_num)+"l"+String(myDat.legs_num)+".png"
        myraPic.image=UIImage(named:myDat.myraInfo)
        
    }
    
    @IBAction func legs_back(_ sender: UIButton) {
        
        if myDat.head_num == 0 {
            myDat.head_num = 2
            myDat.body_num = 2
            myDat.legs_num = 2
        }
        
        if myDat.legs_num == 1 {
            myDat.legs_num = 3
        } else {
            myDat.legs_num = myDat.legs_num-1
        }
        
        myDat.myraInfo = "h"+String(myDat.head_num)+"b"+String(myDat.body_num)+"l"+String(myDat.legs_num)+".png"
        myraPic.image=UIImage(named:myDat.myraInfo)
        
        
    }

    
    

//
//    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "myraSaveSegue" ,
//            let nextScene = segue.destination as? MainViewController  {
//            nextScene.myraInfo = myraInfo
//            nextScene.mathInfo = mathInfo
//            nextScene.head_num = head_num
//            nextScene.body_num = body_num
//            nextScene.legs_num = legs_num
//            
//        }
//        
//        if segue.identifier == "myraCancelSegue" ,
//            let nextScene = segue.destination as? MainViewController  {
//            myraInfo = myraTempTag
//            nextScene.myraInfo = myraInfo
//            nextScene.mathInfo = mathInfo
//            nextScene.head_num = head_num
//            nextScene.body_num = body_num
//            nextScene.legs_num = legs_num
//            
//        }
//        
//        
//        
//    }

    

    
    override func viewDidAppear(_ animated: Bool) {
        
        print("VIEW DID LOAD")
        print(myDat.myraInfo)
        
        
    //    print(myraInfo)
//               myraPic.image=UIImage(named:myraInfo!)
//            myraTempTag = myraInfo
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("in viewdidload")
        
        print("entering Myra view controller")
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    
    
    
    
}
