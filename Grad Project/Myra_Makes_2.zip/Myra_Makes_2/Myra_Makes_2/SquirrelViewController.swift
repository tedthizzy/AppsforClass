//
//  SquirrelViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 2/25/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class SquirrelViewController: UIViewController {
    
    var myDat = myraData()

//    var myraInfo:String!
//    var mathInfo:Int!
//    var head_num: Int!
//    var body_num: Int!
//    var legs_num: Int!
    
    @IBOutlet weak var mathLabel: UILabel!

    @IBOutlet weak var mathImage: UIImageView!

    @IBOutlet weak var next_pic: UIImageView!
    
    @IBOutlet weak var subLabel: UILabel!
    @IBOutlet weak var textInput: UITextField!
    
    @IBOutlet weak var mainMyraPic: UIImageView!
    @IBOutlet weak var background_image: UIImageView!
    @IBOutlet weak var squirrelly: UIImageView!
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
        let compSepByCharInSet = string.components(separatedBy: aSet)
        let numberFiltered = compSepByCharInSet.joined(separator: "")
        return string == numberFiltered
    }
    
    
    @IBAction func nextButton(_ sender: UIButton) {
        print(myDat.mathInfo)
        
        if myDat.mathInfo == 0 {
            myDat.mathInfo = 1
        }
        
        if myDat.mathInfo < 7 {
  
            
            if myDat.mathInfo == 6{
                if textInput.text == "14" {
                    subLabel.text = "You Are Right!"
                    myDat.mathInfo = myDat.mathInfo+1

                    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }

            
            if myDat.mathInfo == 5{
                if textInput.text == "24" {
                    subLabel.text = "You Are Right!"
                    myDat.mathInfo = myDat.mathInfo+1

                    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }
            
            if myDat.mathInfo == 4{
                if textInput.text == "16" {
                    subLabel.text = "You Are Right!"
                    myDat.mathInfo = myDat.mathInfo+1

                    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }
            if myDat.mathInfo == 3{
                if textInput.text == "10" {
                    subLabel.text = "You Are Right!"
                    myDat.mathInfo = myDat.mathInfo+1

                    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }
            
            if myDat.mathInfo == 2{
                if textInput.text == "9" {
                    subLabel.text = "You Are Right!"
                    myDat.mathInfo = myDat.mathInfo+1

                    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }
            
            if myDat.mathInfo == 1{
                if textInput.text == "5" {
                    subLabel.text = "You Are Right!"
                    myDat.mathInfo = myDat.mathInfo+1

                    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                    print("in else 1")
                }
            }
            
            if myDat.mathInfo < 6  {
                mathLabel.text="How many acorns can you count?"
            } else {
                mathLabel.text="Can you solve this acorn math?"
            }
            
        } else {

            if myDat.mathInfo == 9 {
                
                    mathLabel.text="How many acorns can you count?"
                    subLabel.text = "Starting the math over"
                    myDat.mathInfo = 1
                    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
                
                squirrelly.image=UIImage(named:"squirrelBubble.png")

                
            }

            
            if myDat.mathInfo == 8 {
                
                if textInput.text == "4" {
                    mathLabel.text="You Finished All The Math!"
                    subLabel.text = "Tap on the bubble to start over"
                    myDat.mathInfo = myDat.mathInfo+1
                    mathImage.image=UIImage(named:"didit.png")
                    squirrelly.image=UIImage(named:"squirrel_done.png")
//                    next_pic.image=UIImage(named: "nav_end.png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }

            }
            
            if myDat.mathInfo == 7 {
                
                if textInput.text == "6" {
                    subLabel.text = "You Are Right!"
                    myDat.mathInfo = myDat.mathInfo+1
                    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
  //                  next_pic.image=UIImage(named: "nav_end.png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
                
            }
            
        }

    }
    
    /*
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "takePicSegue"{
            let itemViewController = segue.destinationViewController as! Item_ViewController
            itemViewController.page_num=page_num
        }
    }
    */
    
    
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "backSegue" ,
//            let nextScene = segue.destination as? MainViewController  {
//            nextScene.myraInfo = myraInfo
//            nextScene.mathInfo = mathInfo
//            nextScene.head_num = head_num
//            nextScene.body_num = body_num
//            nextScene.legs_num = legs_num
//            
//        }
//    }
    

    override func viewDidAppear(_ animated: Bool) {
        
        print("VIEW DID APPEAR")
        print(myDat.mathInfo)
//        mainMyraPic.image=UIImage(named:myDat.myraInfo)

    myDat.mathInfo = 1
    mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("VIEW DID LOAD")
        print(myDat.mathInfo)
        
 //       mainMyraPic.image=UIImage(named:myDat.myraInfo)
        myDat.mathInfo = 1
        mathImage.image=UIImage(named:"math"+String(myDat.mathInfo)+".png")
    
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func willRotate(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        if (toInterfaceOrientation.isLandscape) {
            background_image.image = UIImage (named: "for_horz.png")
        }
        else {
            background_image.image = UIImage (named: "for_vert.png")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
