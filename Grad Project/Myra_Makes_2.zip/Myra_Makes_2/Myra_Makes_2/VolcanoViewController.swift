//
//  VolcanoViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick M Thayer on 4/30/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class VolcanoViewController: UIViewController {
    
    var myDat = myraData()
    
    //    var myraInfo:String!
    //    var mathInfo:Int!
    //    var head_num: Int!
    //    var body_num: Int!
    //    var legs_num: Int!
    
    @IBOutlet weak var animLabel: UILabel!
    
    @IBOutlet weak var animImage: UIImageView!
    
    @IBOutlet weak var next_pic: UIImageView!
    
    
    @IBOutlet weak var textInput: UITextField!
    
    @IBOutlet weak var background_image: UIImageView!
    
    
    @IBAction func nextClick(_ sender: UIButton) {

        print(myDat.animInfo)
        
        if myDat.animInfo == 0 {
            myDat.animInfo = 1
        }
        
        if myDat.animInfo < 6 {

            if myDat.animInfo == 5{
                if textInput.text == "crab" {
                    
                    animLabel.text="You named all the animals!"
                    
                    myDat.animInfo = myDat.animInfo+1
                    
                    animImage.image=UIImage(named:"allAnims.png")
                }
            }
            
            if myDat.animInfo == 4{
                if textInput.text == "goat" {
                    myDat.animInfo = myDat.animInfo+1
                    
                    animImage.image=UIImage(named:"anim"+String(myDat.animInfo)+".png")
                }
            }

            if myDat.animInfo == 3{
                if textInput.text == "monkey" {
                    myDat.animInfo = myDat.animInfo+1
                    
                    animImage.image=UIImage(named:"anim"+String(myDat.animInfo)+".png")
                }
            }
            
            if myDat.animInfo == 2{
                if textInput.text == "whale" {
                    myDat.animInfo = myDat.animInfo+1
                    
                    animImage.image=UIImage(named:"anim"+String(myDat.animInfo)+".png")
                } else {
                }
            }
            
            if myDat.animInfo == 1{
                if textInput.text == "squirrel" {
                    myDat.animInfo = myDat.animInfo+1
                    
                    animImage.image=UIImage(named:"anim"+String(myDat.animInfo)+".png")
                }
            }
            
            
        } else {
            
            if myDat.mathInfo == 6 {
                
                animLabel.text="Starting Over..."

                myDat.animInfo = 1
                    animImage.image=UIImage(named:"anim"+String(myDat.animInfo)+".png")
                
                
                
            }
            
        }
        
    }
    
    /*
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     if segue.identifier == "takePicSegue"{
     let itemViewController = segue.destinationViewController as! Item_ViewController
     itemViewController.page_num=page_num
     }
     }
     */
    
    
    
    //    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    //        if segue.identifier == "backSegue" ,
    //            let nextScene = segue.destination as? MainViewController  {
    //            nextScene.myraInfo = myraInfo
    //            nextScene.mathInfo = mathInfo
    //            nextScene.head_num = head_num
    //            nextScene.body_num = body_num
    //            nextScene.legs_num = legs_num
    //
    //        }
    //    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        print("VIEW DID APPEAR")
        print(myDat.mathInfo)
        //        mainMyraPic.image=UIImage(named:myDat.myraInfo)
        
        myDat.animInfo = 1
        animImage.image=UIImage(named:"anim"+String(myDat.animInfo)+".png")
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("VIEW DID LOAD")
        print(myDat.mathInfo)
        
        //       mainMyraPic.image=UIImage(named:myDat.myraInfo)
        myDat.animInfo = 1
        animImage.image=UIImage(named:"anim"+String(myDat.animInfo)+".png")
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func willRotate(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        if (toInterfaceOrientation.isLandscape) {
            background_image.image = UIImage (named: "vol_horz.png")
        }
        else {
            background_image.image = UIImage (named: "vol_vert.png")
        }
    }
    
    
}
