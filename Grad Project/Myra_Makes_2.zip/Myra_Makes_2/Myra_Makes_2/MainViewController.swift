//
//  MainViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 2/25/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class MainViewController: UIViewController ,
    UIImagePickerControllerDelegate,
UINavigationControllerDelegate {
    
    @IBOutlet weak var thisImage: UIImageView!
    @IBOutlet weak var background_image: UIImageView!
    
    var imagePicker: UIImagePickerController!
    
    @IBAction func takePicButton(_ sender: UIButton) {
        
        imagePicker =  UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .camera
        
        present(imagePicker, animated: true, completion: nil)
        
    }
    
func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
    imagePicker.dismiss(animated: true, completion: nil)
        thisImage.image = info[UIImagePickerControllerOriginalImage] as? UIImage
    }
    // this will crash because it is in simulator but should work on a real iPad
    
    override func willRotate(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        if (toInterfaceOrientation.isLandscape) {
            background_image.image = UIImage (named: "mtn_horz.png")
        }
        else {
            background_image.image = UIImage (named: "mtn_vert.png")
        }
    }
}
