//
//  myraSwiftData.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 3/13/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import Foundation

class myraData{
    var myraInfo = [String]()
    var mathInfo = [Int]()
    var head_num = [Int]()
    var body_num = [Int]()
    var legs_num = [Int]()
}
