//
//  MainViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 2/25/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

//    let myData = myraData()
    
    @IBOutlet weak var mainMyraPic: UIImageView!
    var myraInfo:String!
    var mathInfo:Int!

    var head_num: Int! //= 1
    var body_num: Int! //= 1
    var legs_num: Int! //= 1

    @IBOutlet weak var background_image: UIImageView!

    
    
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "myraSegue" ,
            let nextScene = segue.destination as? MyraViewController  {
            nextScene.myraInfo = myraInfo
            nextScene.mathInfo = mathInfo
            nextScene.head_num = head_num
            nextScene.body_num = body_num
            nextScene.legs_num = legs_num
            
        }
        
        if segue.identifier == "mathSegue" ,
            let nextScene = segue.destination as? SquirrelViewController  {
            nextScene.myraInfo = myraInfo
            nextScene.mathInfo = mathInfo
            nextScene.head_num = head_num
            nextScene.body_num = body_num
            nextScene.legs_num = legs_num
            
        }

        
        if segue.identifier == "helpSegue" ,
            let nextScene = segue.destination as? HowToUseViewController  {
            nextScene.myraInfo = myraInfo
            nextScene.mathInfo = mathInfo
            nextScene.head_num = head_num
            nextScene.body_num = body_num
            nextScene.legs_num = legs_num
            
        }

        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        //    print(myraInfo)
        mainMyraPic.image=UIImage(named:myraInfo!)
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        print("entering main view controller")
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func willRotate(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        if (toInterfaceOrientation.isLandscape) {
            background_image.image = UIImage (named: "horizontal_background.png")
        }
        else {
            background_image.image = UIImage (named: "vertical_background.png")
        }
    }
}
