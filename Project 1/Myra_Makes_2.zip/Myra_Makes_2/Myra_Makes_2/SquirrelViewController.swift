//
//  SquirrelViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 2/25/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class SquirrelViewController: UIViewController {

    var myraInfo:String!
    var mathInfo:Int!
    var head_num: Int!
    var body_num: Int!
    var legs_num: Int!
    
    @IBOutlet weak var mathLabel: UILabel!
    @IBOutlet weak var mathImage: UIImageView!
    @IBOutlet weak var next_pic: UIImageView!
    
    @IBOutlet weak var subLabel: UILabel!
    @IBOutlet weak var textInput: UITextField!
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
        let compSepByCharInSet = string.components(separatedBy: aSet)
        let numberFiltered = compSepByCharInSet.joined(separator: "")
        return string == numberFiltered
    }
    
    
    @IBAction func nextButton(_ sender: UIButton) {
        print(mathInfo)
        
        if mathInfo < 7 {
            
            

            

            


            
            if mathInfo == 6{
                if textInput.text == "14" {
                    subLabel.text = "You Are Right!"
                    mathInfo = mathInfo+1
                    next_pic.image=UIImage(named: "nav_next.png")
                    mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }

            
            if mathInfo == 5{
                if textInput.text == "24" {
                    subLabel.text = "You Are Right!"
                    mathInfo = mathInfo+1
                    next_pic.image=UIImage(named: "nav_next.png")
                    mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }
            
            if mathInfo == 4{
                if textInput.text == "16" {
                    subLabel.text = "You Are Right!"
                    mathInfo = mathInfo+1
                    next_pic.image=UIImage(named: "nav_next.png")
                    mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }
            if mathInfo == 3{
                if textInput.text == "10" {
                    subLabel.text = "You Are Right!"
                    mathInfo = mathInfo+1
                    next_pic.image=UIImage(named: "nav_next.png")
                    mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }
            
            if mathInfo == 2{
                if textInput.text == "9" {
                    subLabel.text = "You Are Right!"
                    mathInfo = mathInfo+1
                    next_pic.image=UIImage(named: "nav_next.png")
                    mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
            }
            
            if mathInfo == 1{
                if textInput.text == "5" {
                    subLabel.text = "You Are Right!"
                    mathInfo = mathInfo+1
                    next_pic.image=UIImage(named: "nav_next.png")
                    mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                    print("in else 1")
                }
            }
            
            if mathInfo < 6  {
                mathLabel.text="How many acorns can you count?"
            } else {
                mathLabel.text="Can you solve this acorn math?"
            }
            
        } else {

            if mathInfo == 9 {
                
                    mathLabel.text="How many acorns can you count?"
                    subLabel.text = "Starting the math over"
                    mathInfo = 1
                    mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
                    next_pic.image=UIImage(named: "nav_next.png")
                
            }

            
            if mathInfo == 8 {
                
                if textInput.text == "4" {
                    mathLabel.text="You Finished All The Math!"
                    subLabel.text = "Tap on the bubble to start over"
                    mathInfo = mathInfo+1
                    mathImage.image=UIImage(named:"squirrel_done.png")
                    next_pic.image=UIImage(named: "nav_end.png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }

            }
            
            if mathInfo == 7 {
                
                if textInput.text == "6" {
                    subLabel.text = "You Are Right!"
                    mathInfo = mathInfo+1
                    mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
                    next_pic.image=UIImage(named: "nav_end.png")
                } else {
                    subLabel.text = "Not Right, Try Again!"
                }
                
            }
            
        }

    }
    
    /*
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "takePicSegue"{
            let itemViewController = segue.destinationViewController as! Item_ViewController
            itemViewController.page_num=page_num
        }
    }
    */
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "backSegue" ,
            let nextScene = segue.destination as? MainViewController  {
            nextScene.myraInfo = myraInfo
            nextScene.mathInfo = mathInfo
            nextScene.head_num = head_num
            nextScene.body_num = body_num
            nextScene.legs_num = legs_num
            
        }
    }
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        mathImage.image=UIImage(named:"math"+String(mathInfo)+".png")
    
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
