//
//  FirstViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 3/13/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    
    var myraInfo:String = "h1b1l1.png"
    var mathInfo:Int = 1
    var head_num:Int = 1
    var body_num:Int = 2
    var legs_num:Int = 3
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "firstSegue" ,
            let nextScene = segue.destination as? MainViewController  {
            nextScene.myraInfo = myraInfo
            nextScene.mathInfo = mathInfo
            nextScene.head_num = head_num
            nextScene.body_num = body_num
            nextScene.legs_num = legs_num

        }
    }

    /*
    func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "firstSegue" {
            var destination = segue.destination as! MainViewController {
                
                
                destination.myraInfo = myraInfo
                destination.mathInfo = mathInfo
                destination.head_num = head_num
                destination.body_num = body_num
                destination.legs_num = legs_num
            }
        }
    }

 */
    

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }


}
