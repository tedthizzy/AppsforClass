//
//  HowToUseViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 2/25/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class HowToUseViewController: UIViewController {
    
    
    
    var myraInfo:String!
    var mathInfo:Int!
    
    var head_num: Int! //= 1
    var body_num: Int! //= 1
    var legs_num: Int! //= 1
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "helpBackSegue" ,
            let nextScene = segue.destination as? MainViewController  {
            nextScene.myraInfo = myraInfo
            nextScene.mathInfo = mathInfo
            nextScene.head_num = head_num
            nextScene.body_num = body_num
            nextScene.legs_num = legs_num
            
        }
    }
        
}
