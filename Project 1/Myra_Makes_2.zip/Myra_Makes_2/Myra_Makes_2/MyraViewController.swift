//
//  MyraViewController.swift
//  Myra_Makes_2
//
//  Created by Frederick Thayer on 2/25/17.
//  Copyright © 2017 FMT. All rights reserved.
//

import UIKit

class MyraViewController: UIViewController {

    
    @IBOutlet weak var myraPic: UIImageView!
    
    var myraInfo:String!
    var mathInfo:Int!

    
    var myraTempTag: String! = ""
//    let myraTempTag = myraInfo//= "h1b1l1"
    var head_num: Int! //= 1
    var body_num: Int! //= 1
    var legs_num: Int! //= 1
    
    
    
    
    
    @IBAction func head_next(_ sender: UIButton) {
        
        if head_num == 3 {
            head_num = 1
        } else {
            head_num = head_num+1
        }
        
        myraInfo = "h"+String(head_num)+"b"+String(body_num)+"l"+String(legs_num)+".png"
        myraPic.image=UIImage(named:myraInfo!)
        
    }
    
    @IBAction func body_next(_ sender: UIButton) {
        
        if body_num == 3 {
            body_num = 1
        } else {
            body_num = body_num+1
        }
        
        myraInfo = "h"+String(head_num)+"b"+String(body_num)+"l"+String(legs_num)+".png"
        myraPic.image=UIImage(named:myraInfo!)
        
    }
    
    @IBAction func legs_next(_ sender: UIButton) {
        
        if legs_num == 3 {
            legs_num = 1
        } else {
            legs_num = legs_num+1
        }
        
        myraInfo = "h"+String(head_num)+"b"+String(body_num)+"l"+String(legs_num)+".png"
        myraPic.image=UIImage(named:myraInfo!)
        
    }
    
    @IBAction func head_back(_ sender: UIButton) {
        
        if head_num == 1 {
            head_num = 3
        } else {
            head_num = head_num-1
        }
        
        myraInfo = "h"+String(head_num)+"b"+String(body_num)+"l"+String(legs_num)+".png"
        myraPic.image=UIImage(named:myraInfo!)
        
    }
    
    @IBAction func body_back(_ sender: UIButton) {
        
        if body_num == 1 {
            body_num = 3
        } else {
            body_num = body_num-1
        }
        
        myraInfo = "h"+String(head_num)+"b"+String(body_num)+"l"+String(legs_num)+".png"
        myraPic.image=UIImage(named:myraInfo!)
        
    }
    
    @IBAction func legs_back(_ sender: UIButton) {
        
        if legs_num == 1 {
            legs_num = 3
        } else {
            legs_num = legs_num-1
        }
        
        myraInfo = "h"+String(head_num)+"b"+String(body_num)+"l"+String(legs_num)+".png"
        myraPic.image=UIImage(named:myraInfo!)
        
    }

    
    


    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "myraSaveSegue" ,
            let nextScene = segue.destination as? MainViewController  {
            nextScene.myraInfo = myraInfo
            nextScene.mathInfo = mathInfo
            nextScene.head_num = head_num
            nextScene.body_num = body_num
            nextScene.legs_num = legs_num
            
        }
        
        if segue.identifier == "myraCancelSegue" ,
            let nextScene = segue.destination as? MainViewController  {
            myraInfo = myraTempTag
            nextScene.myraInfo = myraInfo
            nextScene.mathInfo = mathInfo
            nextScene.head_num = head_num
            nextScene.body_num = body_num
            nextScene.legs_num = legs_num
            
        }
        
        
        
    }

    

    
    override func viewDidAppear(_ animated: Bool) {
        
    //    print(myraInfo)
               myraPic.image=UIImage(named:myraInfo!)
            myraTempTag = myraInfo
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("in viewdidload")
        
        
        
        print("entering Myra view controller")
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    
    
    
    
}
