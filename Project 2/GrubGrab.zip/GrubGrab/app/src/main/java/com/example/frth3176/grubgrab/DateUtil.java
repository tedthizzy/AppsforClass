package com.example.frth3176.grubgrab;

/**
 * Created by frth3176 on 4/29/17.
 */

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Calendar;



public class DateUtil {

    public static Date addDays(Date date, int days)

    {

        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); //minus number would decrement the days
        return cal.getTime();

    }

}



