package com.example.frth3176.grubgrab;



import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class WeekActivity extends ListActivity {

    private String year;
    private String month;
    private String dayOfMonth;
    private Date thisDate;

    public static final String[] DaysInWeek = new String[7];


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        Intent i = getIntent();

        year = i.getStringExtra("year");
        month = i.getStringExtra("month");
        dayOfMonth = i.getStringExtra("dayOfMonth");

        String thisDate = i.getStringExtra("thisDate");

        String sourceDate = thisDate;

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        Date myDate = null;

        try {

            myDate = format.parse(sourceDate);

        } catch (ParseException e) {

            e.printStackTrace();

        }

        //myDate = DateUtil.addDays(myDate, 1);


        for(int n=0;n<7;n++) {

            String tempString = String.valueOf(DateUtil.addDays(myDate, n));
            String[] tempParts = tempString.split("00:00:00 MDT");
            String tempMerge = tempParts[0] + tempParts[1];

            DaysInWeek[n] = tempMerge;

        }


        Log.d("thisDate: ", thisDate);

        Log.d("DaysInWeek[0]: ", DaysInWeek[0]);
        Log.d("DaysInWeek[1]: ", DaysInWeek[1]);
        Log.d("DaysInWeek[2]: ", DaysInWeek[2]);

        ListView listDaysInWeek = getListView();

        ArrayAdapter<String> itemsAdapter =

                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, DaysInWeek);

        //       ListView listView = (ListView) findViewById(R.id.lvItems);

        listDaysInWeek.setAdapter(itemsAdapter);

    }


    @Override

    public void onListItemClick(ListView listView, View view, int position, long id) {

        Intent intent = new Intent(WeekActivity.this, DayActivity.class);
        intent.putExtra("dayId",(int) id);
        intent.putExtra("thisDay", DaysInWeek[position]);

        //intent.putExtra("thisDate",thisDate);

        startActivity(intent);

    }

}

