package com.example.frth3176.grubgrab;

import android.app.ListActivity;

import android.content.Intent;

import android.os.Bundle;

import android.util.Log;
import android.view.View;

import android.widget.ArrayAdapter;

import android.widget.ListView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DayActivity extends ListActivity {

    private String thisDay;
    String thisDate = "placeholder";

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        thisDate = i.getStringExtra("thisDay");

        ListView listEvents = getListView();

        ArrayAdapter<Food> listAdapter;

        switch (thisDate){

            case "Mon May 01  2017":

                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.MayOne);
                break;

            case "Tue May 02  2017":

                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.MayTwo);
                break;

            case "Wed May 03  2017":

                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.MayThree);
                break;

            case "Thu May 04  2017":

                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.MayFour);
                break;

            case "Fri May 05  2017":

                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.MayFive);
                break;

            default: listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.NoEvents);
                // default: show text that says "no events today!"

        }

        listEvents.setAdapter(listAdapter);

    }

    @Override

    public void onListItemClick(ListView listView, View view, int position, long id) {

        Intent intent = new Intent(DayActivity.this, EventActivity.class);
        intent.putExtra("eventId",(int) id);
        intent.putExtra("thisDay", thisDate);

        //intent.putExtra("thisEvent",thisEvent);

        startActivity(intent);

    }

}







