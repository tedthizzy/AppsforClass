package com.example.frth3176.grubgrab;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;


public class EventActivity extends Activity {


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        Intent i = getIntent();
     //   thisDate = i.getStringExtra("thisDay");

        int foodnum = (Integer) getIntent().getExtras().get("eventId");
        String type = i.getStringExtra("thisDay");

        Food food;

        if (type.equals("Mon May 01  2017")) {

            food = Food.MayOne[foodnum];

        } else {

            if (type.equals("Tue May 02  2017")) {

                food = Food.MayTwo[foodnum];

            } else {

                if (type.equals("Wed May 03  2017")) {

                    food = Food.MayThree[foodnum];

                } else {

                    if (type.equals("Thu May 04  2017")) {

                        food = Food.MayFour[foodnum];

                    } else {

                        if (type.equals("Fri May 05  2017")) {

                            food = Food.MayFive[foodnum];
                        } else {

                            food = Food.NoEvents[foodnum];

                        }
                    }

                }

            }

        }

        ImageView foodImage = (ImageView) findViewById(R.id.foodImageView);
        foodImage.setImageResource(food.getImageResourceID());

        TextView foodName = (TextView) findViewById(R.id.food_name);
        foodName.setText(food.getName());

        TextView foodLoc = (TextView) findViewById(R.id.food_location);
        foodLoc.setText(food.getLoc());

        TextView foodTime = (TextView) findViewById(R.id.food_time);
        foodTime.setText(food.getTime());

    }


}

