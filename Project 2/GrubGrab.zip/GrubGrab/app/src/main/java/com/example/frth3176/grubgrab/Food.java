package com.example.frth3176.grubgrab;

/**
 * Created by frth3176 on 4/29/17.
 */
public class Food {

    private String name;
    private String location;
    private String time;
    private int imageResourceID;

    private Food(String newname, String newloc, String newtime, int newID){

        this.name = newname;
        this.location = newloc;
        this.time = newtime;
        this.imageResourceID = newID;

    }

    public static final Food[] MayOne = {

            new Food("Take Back the Tap", "UMC 201", "12:00pm", R.drawable.tap),
            new Food("Alumni Breakfast", "CU Alumni Center", "4:00pm", R.drawable.alumni),
            new Food("Physics Colloquim", "Duane Physics 100", "5:00pm", R.drawable.physics),

    };

    public static final Food[] MayTwo = {

            new Food("Church Sandwhich Making", "Christan Church", "2:00pm", R.drawable.pbj),

    };

    public static final Food[] MayThree = {

            new Food("Flying Sphaggheti Monster Club Meeting", "Heaven", "11:11am", R.drawable.pasta),
            new Food("ATLAS Expo Night", "Black Box Studio", "5:00pm", R.drawable.expo),

    };

    public static final Food[] MayFour = {

                   new Food("Thirsty Thursdays", "The Hill", "11:00am", R.drawable.popo),
                   new Food("Mobile Makers", "ATLAS 204", "5:00pm", R.drawable.makers),

    };

    public static final Food[] MayFive = {

                   new Food("Engineers without Borders", "ECEN 350", "5:00pm", R.drawable.border),
                   new Food("Drone Club", "ATLAS 100", "5:30pm", R.drawable.drone),

    };

    public static final Food[] NoEvents = {

            new Food("No Events Today!", "n/a", "n/a", R.drawable.sad),

    };

    public String getName(){

        return name;

    }

    public String getLoc(){

        return location;

    }

    public String getTime(){

        return time;

    }


    public int getImageResourceID(){

        return imageResourceID;

    }

    public String toString(){

        return this.name;

    }

}



