package com.example.ted.grubgrab1;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.widget.CalendarView;
import android.widget.CalendarView.OnDateChangeListener;
import android.widget.GridLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.Toast;

import ted.grubgrab1.R;

public class MainActivity extends Activity {

    RelativeLayout rl;
    CalendarView cal;
    String date = "placeholder";

    @SuppressLint({ "NewApi","NewApi" })
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rl = (RelativeLayout) findViewById(R.id.rl);

        cal = new CalendarView(MainActivity.this);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams
                ((int) LayoutParams.MATCH_PARENT, (int) LayoutParams.MATCH_PARENT);

        params.topMargin = 100;
        cal.setLayoutParams(params);

        rl.addView(cal);

        cal.setOnDateChangeListener(new OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month,
                                            int dayOfMonth) {
                Toast.makeText(getBaseContext(),"Selected Date is\n\n"
                                +dayOfMonth+" : "+month+" : "+year ,
                        Toast.LENGTH_LONG).show();
                date = year + "-" + month + "-" + dayOfMonth;
                Intent intent = new Intent(MainActivity.this, WeekActivity.class);
                intent.putExtra("year",year);
                intent.putExtra("month",month);
                intent.putExtra("dayOfMonth",dayOfMonth);
                intent.putExtra("date",date);
                startActivity(intent);
                //startActivity(new Intent(MainActivity.this, WeekActivity.class));

            }
        });
    }
//
//    @Override public void onCreateContextMenu(ContextMenu menu, View v,ContextMenuInfo menuInfo){
//        super.onCreateContextMenu(menu, v, menuInfo);
//        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
//        menu.setHeaderTitle("Go to " + date);
//        menu.add(1,1,1,"Yes");
//        menu.add(2,2,2, "No");
//    }
//
//    @Override
//    public boolean onContextItemSelected(MenuItem item) {
//        if(item.getTitle()=="Action 1"){function1(item.getItemId());}
//        else if(item.getTitle()=="Action 2"){function2(item.getItemId());}
//        else {return false;}
//        return true;
//    }
//
//    public void function1(int id){
//        Toast.makeText(this, "function 1 called", Toast.LENGTH_SHORT).show();
//    }
//    public void function2(int id){
//        Toast.makeText(this, "function 2 called", Toast.LENGTH_SHORT).show();
//    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
}
