package com.example.ted.grubgrab1;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.text.SimpleDateFormat;
import java.util.Date;


public class WeekActivity extends ListActivity {



    private String year;
    private String month;
    private String dayOfMonth;
    private String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        year = i.getStringExtra("year");
        month = i.getStringExtra("month");
        dayOfMonth = i.getStringExtra("dayOfMonth");
        date = i.getStringExtra("date");

        String sourceDate = date;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date myDate = format.parse(sourceDate);
        myDate = DateUtil.addDays(myDate, 1);


        ListView listDaysInWeek = getListView();

        String[] DaysInWeek = new String[7];

        for(int n=0;n<7;n++) {


            if(n == 0){
                DaysInWeek[n] = date;
            } else {
                if(dayOfMonth + n == 32){
                    dayOfMonth
                    month=month++;
                }
                if(month == 1){
                    if(dayOfMonth+n =
                }
            }

            System.out.println(mStrings[i]);
        }

        DaysInWeek = Array("1","2","3");

        ArrayAdapter<DaysInWeek> listAdapter;

        switch (foodtype){
            case "Breakfast":
                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.breakfast);
                break;
            case "Lunch":
                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.lunch);
                break;
            case "Dinner":
                listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.dinner);
                break;
            default: listAdapter = new ArrayAdapter<Food>(this, android.R.layout.simple_list_item_1, Food.breakfast);
        }

        listDaysInWeek.setAdapter(listAdapter);

    }

    @Override
    public void onListItemClick(ListView listView, View view, int position, long id) {
        Intent intent = new Intent(DayActivity.this, EventActivity.class);
        intent.putExtra("foodid",(int) id);
        intent.putExtra("foodtype",foodtype);
        startActivity(intent);
    }

}


// Activity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_week);
//
//        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
//            public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
//                String foodtype = (String) listView.getItemAtPosition(position);
//                Intent intent = new Intent(WeekActivity.this, DayActivity.class);
//                intent.putExtra("foodtype",foodtype);
//                startActivity(intent);
//            }
//        };
//
//        ListView listview = (ListView) findViewById(R.id.listView);
//        listview.setOnItemClickListener(itemClickListener);
//    }
//
//    public boolean onCreateOptionsMenu(Menu menu){
//
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return super.onCreateOptionsMenu(menu);
//    }
//
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()){
//
//            case R.id.create_order:
//                Intent intent = new Intent(this, OrderActivity.class);
//                startActivity(intent);
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//
//        }
//    }
//}
